package com.tezwall.tisittask.view.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.tezwall.tisittask.R;
import com.tezwall.tisittask.model.RecentData;
import com.tezwall.tisittask.presenter.RetrofitClient;
import com.tezwall.tisittask.view.adapter.RecentAdapter;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Task2Activity extends Activity {

    private ProgressDialog progress;
    RecyclerView recyclerView;
    ArrayList<RecentData> myListData;
    RecentAdapter rAdapter;
    RecentData dataModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task2);

        recyclerView = (RecyclerView)findViewById(R.id.recycler);
        myListData = new ArrayList<RecentData>();

       /* dataModel = new RecentData("Mani", "Manivannan","www","1","**Grit is no longer maintained. Check out libgit2/rugged.** Grit gives you object oriented read/write access to Git repositories via Ruby.");
        myListData.add(dataModel);
*/





        getLoadData();
    }


    private void getLoadData() {
        Call<List<RecentData>> call = RetrofitClient.getInstance().getMyApi().getHeroes();
        // Set up progress before call
        final ProgressDialog progressDoalog;

        progressDoalog = new ProgressDialog(Task2Activity.this);
        progressDoalog.setIndeterminate(true);
        progressDoalog.setMessage("Please Wait Loading...");
        progressDoalog.setCanceledOnTouchOutside(false);
        progressDoalog.show();
        progressDoalog.setTitle("Please Wait");
        progressDoalog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        // show it
        progressDoalog.show();
        call.enqueue(new Callback<List<RecentData>>() {
            @Override
            public void onResponse(Call<List<RecentData>> call, Response<List<RecentData>> response) {
                List<RecentData> heroList = response.body();

                //Toast.makeText(getApplicationContext(), response.body().toString(), Toast.LENGTH_SHORT).show();
                System.out.println("@@ OUT PUT : "+response.body().toString());
                progressDoalog.dismiss();

                //Creating an String array for the ListView
                //String[] heroes = new String[heroList.size()];

                //looping through all the heroes and inserting the names inside the string array
                for (int i = 0; i < heroList.size(); i++) {
                   // heroes[i] = heroList.get(i).getName();
                    System.out.println("@@ heroList.get(i).getName()"+heroList.get(i).getName());
                    System.out.println("@@ Avatar_url : "+heroList.get(i).getOwner().getAvatar_url());
                  //  System.out.println("@@ getAvatar_url :"+heroList.get(i).getOwner().getAvatar_url());
                    dataModel = new RecentData(heroList.get(i).getName(), heroList.get(i).getFull_name(),heroList.get(i).getLogin(),heroList.get(i).getId(),heroList.get(i).getDescription(),heroList.get(i).getOwner().getAvatar_url());
                    myListData.add(dataModel);
                }

                rAdapter = new RecentAdapter(myListData,Task2Activity.this);
                recyclerView.setHasFixedSize(true);
                recyclerView.setLayoutManager(new LinearLayoutManager(getApplication()));
                recyclerView.setAdapter(rAdapter);

                //displaying the string array into listview
                //listView.setAdapter(new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, heroes));
            }

            @Override
            public void onFailure(Call<List<RecentData>> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                progressDoalog.dismiss();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(Task2Activity.this,TaskActivity.class));
        finish();
    }
}