package com.tezwall.tisittask;

import android.app.Application;
import android.content.SharedPreferences;

public class AppApplication extends Application {

    public static AppApplication appContext;
    public static SharedPreferences loginsharedPreferences,sharedPreferences;
    public static SharedPreferences.Editor login_editor,editor;

    @Override
    public void onCreate() {
        super.onCreate();


        appContext=this;
        loginsharedPreferences=getSharedPreferences("LOGIN_HMS",MODE_PRIVATE);
        sharedPreferences=getSharedPreferences("HMS",MODE_PRIVATE);

        login_editor=loginsharedPreferences.edit();
        editor=sharedPreferences.edit();

    }


}
