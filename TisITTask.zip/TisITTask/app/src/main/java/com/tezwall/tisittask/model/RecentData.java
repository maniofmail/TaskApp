package com.tezwall.tisittask.model;

import com.google.gson.annotations.SerializedName;

import org.json.JSONObject;

public class RecentData {

    @SerializedName("name")
    private String name;

    @SerializedName("owner")
    private OwnerData owner;

    private String full_name;
    private String login;
    private String id;
    private String description;
    private String imageUrl;


    public RecentData(String name, String full_name, String login, String id, String description,String imageUrl) {
        this.name = name;
        this.full_name = full_name;
        this.login = login;
        this.id = id;
        this.description = description;
        this.imageUrl=imageUrl;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFull_name() {
        return full_name;
    }

    public void setFull_name(String full_name) {
        this.full_name = full_name;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public OwnerData getOwner() {
        return owner;
    }

    public void setOwner(OwnerData owner) {
        this.owner = owner;
    }
}
