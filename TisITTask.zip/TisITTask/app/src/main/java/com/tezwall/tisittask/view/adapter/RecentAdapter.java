package com.tezwall.tisittask.view.adapter;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;
import com.tezwall.tisittask.AppApplication;
import com.tezwall.tisittask.R;
import com.tezwall.tisittask.model.RecentData;
import com.tezwall.tisittask.view.ui.DetailsActivity;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class RecentAdapter extends RecyclerView.Adapter<RecentAdapter.ViewHolder>{
    private static ArrayList<RecentData> listdata;
    ArrayList<RecentData> myListDatatemp;
    static Context context;
    private static ProgressDialog progress;
    private static String r_id;

    List<RecentData> sliderImg;


    // RecyclerView recyclerView;
    public RecentAdapter(ArrayList<RecentData> listdata , Context context) {
        this.listdata = listdata;
        this.myListDatatemp = new ArrayList<RecentData>();
        this.myListDatatemp.addAll(listdata);
        this.context = context;
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.item_layout, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final RecentData myListData = listdata.get(position);
        holder.title_text_id.setText(listdata.get(position).getName());
        holder.title_text_desc.setText(listdata.get(position).getDescription());

        Picasso.with(AppApplication.appContext)
                .load(listdata.get(position).getImageUrl())
                //.resize(600, 200)// resizes the image to these dimensions (in pixel). does not respect aspect ratio
                .into(holder.p_imageView);

    }


    @Override
    public int getItemCount() {
        return listdata.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        public ImageView p_imageView;
        public TextView title_text_id,title_text_desc;

        public ViewHolder(View itemView) {
            super(itemView);
            this.p_imageView = (ImageView) itemView.findViewById(R.id.i_p_img);

            this.title_text_id = (TextView) itemView.findViewById(R.id.txt_profile_id);
            this.title_text_desc = (TextView) itemView.findViewById(R.id.txt_desc);

            itemView.setOnClickListener(this);


        }

        @Override
        public void onClick(View v) {


            AppApplication.login_editor.putString("IMG",listdata.get(getAdapterPosition()).getImageUrl().toString());
            AppApplication.login_editor.putString("NAME",listdata.get(getAdapterPosition()).getName().toString());
            AppApplication.login_editor.putString("DESC",listdata.get(getAdapterPosition()).getDescription().toString());
            AppApplication.login_editor.commit();

            Intent intent = new Intent (v.getContext(), DetailsActivity.class);
            v.getContext().startActivity(intent);
            ((Activity)context).finish();

           // VttmApp.showDialogBox((Activity)context);


        }
    }




    // Filter Class
    public void filter(String charText) {
        charText = charText.toLowerCase(Locale.getDefault());
        listdata.clear();
        if (charText.length() == 0) {
            listdata.addAll(myListDatatemp);
        } else {
            for (RecentData lv : myListDatatemp) {
                if (lv.getId() != null &&lv.getId().toLowerCase(Locale.getDefault()).contains(charText)) {
                    listdata.add(lv);
                }
            }
        }
        notifyDataSetChanged();
    }



}
