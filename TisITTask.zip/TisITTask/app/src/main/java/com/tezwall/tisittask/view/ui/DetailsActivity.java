package com.tezwall.tisittask.view.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.tezwall.tisittask.AppApplication;
import com.tezwall.tisittask.R;

public class DetailsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        Picasso.with(AppApplication.appContext)
                .load(AppApplication.loginsharedPreferences.getString("IMG",""))
                //.resize(600, 200)// resizes the image to these dimensions (in pixel). does not respect aspect ratio
                .into((ImageView)findViewById(R.id.i_p_img));

        ((TextView)findViewById(R.id.txt_profile_name)).setText(AppApplication.loginsharedPreferences.getString("NAME",""));
        ((TextView)findViewById(R.id.txt_desc)).setText(AppApplication.loginsharedPreferences.getString("DESC",""));


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(DetailsActivity.this,Task2Activity.class));
        finish();
    }
}